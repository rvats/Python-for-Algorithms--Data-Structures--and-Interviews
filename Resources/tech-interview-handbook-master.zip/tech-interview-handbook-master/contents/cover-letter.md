---
id: cover-letter
title: Cover Letter
---

- A short introduction describing who you are and what you're looking for.
- What projects have you enjoyed working on?
- Which have you disliked? What motivates you?
- Links to online profiles you use (GitHub, Twitter, etc).
- A description of your work history (whether as a resume, LinkedIn profile, or prose).
