# Preparing

The contents have been moved to the [website](https://yangshun.github.io/tech-interview-handbook/coding-round-overview).

<!-- TODO: Remove in future -->
